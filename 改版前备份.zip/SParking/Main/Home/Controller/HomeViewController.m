//
//  HomeViewController.m
//  SParking
//
//  Created by Yazhao on 2018/1/8.
//  Copyright © 2018年 Yazhao. All rights reserved.
//

#import "HomeViewController.h"
#import "HomeLoopViewCell.h"
#import "HomeLocalViewCell.h"
#import "HomeMapViewCell.h"
#import "HomeOpViewCell.h"

#import "PersonalViewController.h"
#import "MapViewController.h"
#import "SMapView.h"
#import "LocationService.h"

#import "HomeModelController.h"

#import "ParkingLot.h"

@interface HomeViewController ()<UICollectionViewDelegateFlowLayout,BMKMapViewDelegate,BMKLocationServiceDelegate>
@property(nonatomic,weak)SMapView *mapView;

@property(nonatomic,strong)HomeModelController *modelController;
@property(nonatomic,strong)NSArray *mapAnns;
@end

@implementation HomeViewController

#pragma mark - 控制器生命周期
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    [self setupNavigationBar];
    [self collectionRegisterViews];
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    //显示导航栏
    self.navigationController.navigationBarHidden=NO;
    
    //注册通知
    [self registerNotifications];
}
-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    
    [self removeNotifications];
    
    _mapView.delegate=nil;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma end - 控制器生命周期

#pragma mark - 属性Getter方法
-(HomeModelController*)modelController{
    if(!_modelController){
        _modelController=[[HomeModelController alloc]init];
    }
    return _modelController;
}
-(NSMutableArray*)mapAnns{
    if(!_mapAnns){
        _mapAnns=[[NSMutableArray alloc]init];
    }
    return _mapAnns;
}
#pragma end - 属性Getter方法

#pragma mark - 视图加载后的一些初始化设置
-(void)setupNavigationBar{
    self.navigationItem.title=@"空位停车";
    
    UIImage *leftImg=[UIImage imageNamed:@"home_nav_contact"];
    self.navigationItem.leftBarButtonItem=[[UIBarButtonItem alloc]initWithImage:leftImg style:UIBarButtonItemStylePlain target:self action:@selector(contactItemClicked:)];
    
    UIImage *rightImg=[UIImage imageNamed:@"home_nav_scan"];
    self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc]initWithImage:rightImg style:UIBarButtonItemStylePlain target:self action:@selector(scanItemClicked:)];
}
-(void)collectionRegisterViews{
    
    [self.collectionView registerClass:HomeLoopViewCell.class forCellWithReuseIdentifier:@"HomeLoopViewCell"];
    
    [self.collectionView registerClass:HomeMapViewCell.class forCellWithReuseIdentifier:@"HomeMapViewCell"];
    
    UINib *nib=[UINib nibWithNibName:@"HomeLocalViewCell" bundle:nil];
    [self.collectionView registerNib:nib forCellWithReuseIdentifier:@"HomeLocalViewCell"];
    
    nib=[UINib nibWithNibName:@"HomeOpViewCell" bundle:nil];
    [self.collectionView registerNib:nib forCellWithReuseIdentifier:@"HomeOpViewCell"];
}
#pragma end - 视图初始化后的一些初始化设置

-(void)registerNotifications{
    NSNotificationCenter *nc=[NSNotificationCenter defaultCenter];
    [nc addObserver:self selector:@selector(userLocationUpdatedNotification:) name:kUserLocationUpdatedNotification object:nil];
}

-(void)removeNotifications{
    NSNotificationCenter *nc=[NSNotificationCenter defaultCenter];
    [nc removeObserver:self name:kUserLocationUpdatedNotification object:nil];
}

-(void)loadNearByParkings:(CLLocationCoordinate2D)pt{
    [self.modelController findParkAround:pt completion:^(NSArray *dataList, NSError *error) {
        NSMutableArray *anns=[[NSMutableArray alloc]init];
        for (ParkingLot *lot in dataList) {
            BMKPointAnnotation *ann=[[BMKPointAnnotation alloc]init];
            ann.coordinate=lot.pt;
            [anns addObject:ann];
        }
        [self performSelectorOnMainThread:@selector(updateMapAnnotations:) withObject:anns waitUntilDone:YES];
    }];
}

-(void)updateMapAnnotations:(NSArray*)anns{
    [_mapView removeAnnotations:_mapAnns];
    
    _mapAnns=anns;
    [_mapView addAnnotations:anns];
}
-(void)userLocationUpdatedNotification:(NSNotification*)note{
    BMKLocationService *locationService=LocationService.sharedService;
    BMKUserLocation *usrLocation=locationService.userLocation;
    
    //更新用户位置
    [_mapView updateLocationData:usrLocation];
    
    CLLocationCoordinate2D pt=usrLocation.location.coordinate;
    //地图中心移动
    [_mapView setCenterCoordinate:pt animated:YES];
    
    //加载周围停车场
    [self loadNearByParkings:pt];
}

-(void)contactItemClicked:(UIBarButtonItem*)item{
    UIStoryboard *sb=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    UIViewController *vc=[sb instantiateViewControllerWithIdentifier:@"PersonalViewController"];
    [self.navigationController pushViewController:vc animated:YES];
}
-(void)scanItemClicked:(UIBarButtonItem*)item{
    
}

-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 4;
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    switch (section) {
        case 3:
            return 2;
            
        default:
            return 1;
    }
}
- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.section) {
        case 0:{
            HomeLoopViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:@"HomeLoopViewCell" forIndexPath:indexPath];
            return cell;
        }
        case 1:{
            HomeLocalViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:@"HomeLocalViewCell" forIndexPath:indexPath];
            return cell;
        }
        case 2:{
            HomeMapViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:@"HomeMapViewCell" forIndexPath:indexPath];
            _mapView=cell.mapView;
            _mapView.delegate=self;
            return cell;
        }
        case 3:{
            HomeOpViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:@"HomeOpViewCell" forIndexPath:indexPath];
            switch (indexPath.row) {
                case 0:
                    cell.imageView.image=[UIImage imageNamed:@"home_parking"];
                    cell.textLabel.textColor=[UIColor colorWithHexString:@"#39C07e"];
                    cell.textLabel.text=@"我要停车";
                    break;
                case 1:
                    cell.imageView.image=[UIImage imageNamed:@"home_car_space"];
                    cell.textLabel.textColor=[UIColor colorWithHexString:@"#fe8719"];
                    cell.textLabel.text=@"我的车位";
                    
                default:
                    break;
            }
            return cell;
        }
            
        default:
            return nil;
    }
}

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    CGFloat width=collectionView.bounds.size.width;
    
    switch (indexPath.section) {
        case 0:
            return CGSizeMake(width, 164);
        case 1:
            return CGSizeMake(width, 48);
        case 2:
            return CGSizeMake(width, collectionView.bounds.size.height-164-48-124-24);
        case 3:
            return CGSizeMake((width-32)/2.0, 124);

        default:
            return CGSizeZero;
            break;
    }
}

-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    switch (section) {
        case 2:
            return UIEdgeInsetsMake(8, 0, 0, 0);
        case 3:
            return UIEdgeInsetsMake(8, 8, 8, 8);

        default:
            return UIEdgeInsetsZero;
    }
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    [collectionView deselectItemAtIndexPath:indexPath animated:YES];
    switch (indexPath.section) {
        case 1:
        case 2:
        case 3:
            if(!indexPath.row){
                UIStoryboard *sb=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
                MapViewController *mapVC=[sb instantiateViewControllerWithIdentifier:@"MapViewController"];
                mapVC.isSearch=(indexPath.section==1)?YES:NO;
                [self.navigationController pushViewController:mapVC animated:YES];
                return;
        }
            
        default:
            break;
    }
}
-(void)collectionView:(UICollectionView *)collectionView didDeselectItemAtIndexPath:(NSIndexPath *)indexPath{
    
}

-(BOOL)collectionView:(UICollectionView *)collectionView shouldHighlightItemAtIndexPath:(NSIndexPath *)indexPath{
    return YES;
}
-(void)collectionView:(UICollectionView *)collectionView didHighlightItemAtIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.section) {
        case 3:{
            UICollectionViewCell *cell = [collectionView cellForItemAtIndexPath:indexPath];
            [cell setBackgroundColor:[UIColor lightGrayColor]];
            return;
        }
            
        default:
            break;
    }
}
-(void)collectionView:(UICollectionView *)collectionView didUnhighlightItemAtIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.section) {
        case 3:{
            UICollectionViewCell *cell = [collectionView cellForItemAtIndexPath:indexPath];
            [cell setBackgroundColor:[UIColor whiteColor]];
            return;
        }
            
        default:
            break;
    }
}

#pragma mark - Map view delegate
-(void)mapViewDidFinishLoading:(BMKMapView *)mapView{
    //读取用户位置
    BMKUserLocation *usrLocation=LocationService.sharedService.userLocation;
    CLLocation *location=usrLocation.location;
    
    if(location){
        //更新用户位置
        [self.mapView updateLocationData:usrLocation];
        
        //用户位置移动到屏幕中心
        CLLocationCoordinate2D center=location.coordinate;
        [mapView setCenterCoordinate:center animated:YES];
        
        //获取屏幕中心附近的停车场
        [self loadNearByParkings:center];
    }
}
-(BMKAnnotationView*)mapView:(BMKMapView *)mapView viewForAnnotation:(id<BMKAnnotation>)annotation{
    //如果是用户自身位置的小蓝点，就什么也不做
    if([annotation isKindOfClass:[BMKUserLocation class]]){
        return nil;
    }
    BMKAnnotationView *anView=[mapView dequeueReusableAnnotationViewWithIdentifier:@"ParingAnnView"];
    if(!anView){
        anView=[[BMKAnnotationView alloc]initWithAnnotation:annotation reuseIdentifier:@"ParingAnnView"];
        anView.image=[UIImage imageNamed:@"map_ann_park"];
    }
    return anView;
}
@end
