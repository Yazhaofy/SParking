//
//  HomeModelController.m
//  SParking
//
//  Created by Yazhao on 2018/1/15.
//  Copyright © 2018年 Yazhao. All rights reserved.
//

#import "HomeModelController.h"
#import "ParkingLot.h"

@implementation HomeModelController
-(void)findParkAround:(CLLocationCoordinate2D)pt completion:(void (^)(NSArray *, NSError *))completion{
    NetworkManager *manager=[NetworkManager manager];
    manager.path=@"NearbyParkingsList";
    manager.params=@{@"Center":[NSString stringWithFormat:@"%f,%f",pt.longitude,pt.latitude],@"Distance":@5};
    manager.method=@"POST";
    
    manager.response = ^(NSDictionary *info, NSError *error) {
        if(error){
            NSLog(@"请求错误");
            completion(nil,error);
            return;
        }
        
        NSInteger code=[info[@"code"]integerValue];
        if(code){
            NSLog(@"%@",info[@"msg"]);
            return;
        }
        
        //正常返回数据
        NSMutableArray *dataList=nil;
        NSArray *result=info[@"result"];
        NSLog(@"%@",result);
        if(result){
            dataList=[[NSMutableArray alloc]init];
            for (NSDictionary *dict in result) {
                ParkingLot *lot=[[ParkingLot alloc]initWithDictionary:dict];
                [dataList addObject:lot];
            }
        }
        
        completion(dataList,nil);
    };
    [manager startRequest];
}
@end
