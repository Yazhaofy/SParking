//
//  HomeModelController.h
//  SParking
//
//  Created by Yazhao on 2018/1/15.
//  Copyright © 2018年 Yazhao. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface HomeModelController : NSObject
-(void)findParkAround:(CLLocationCoordinate2D)pt completion:(void (^)(NSArray *dataList, NSError *error))completion;
@end
