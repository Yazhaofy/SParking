//
//  HomeLocalViewCell.m
//  SParking
//
//  Created by Yazhao on 2018/1/9.
//  Copyright © 2018年 Yazhao. All rights reserved.
//

#import "HomeLocalViewCell.h"

@implementation HomeLocalViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    UIView *view=self.contentView;
    [_cityOptionButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(view);
        make.left.mas_equalTo(view.mas_leftMargin);
        make.bottom.mas_equalTo(view);
    }];
    [_searchTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(view.mas_topMargin);
        make.right.mas_equalTo(view.mas_rightMargin);
        make.bottom.mas_equalTo(view.mas_bottomMargin);
        make.left.mas_equalTo(_cityOptionButton.mas_right).mas_offset(8);
    }];
    [_rightBlankView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(_searchTextField);
        make.bottom.mas_equalTo(_searchTextField);
        make.right.mas_equalTo(_searchTextField);
        make.width.mas_equalTo(_searchTextField.mas_height).dividedBy(2.0);
    }];
    [_searchImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(_rightBlankView.mas_left);
        make.centerY.mas_equalTo(_searchTextField);
    }];
    
    _searchTextField.leftViewMode=UITextFieldViewModeAlways;

    [_searchTextField setContentHuggingPriority:UILayoutPriorityFittingSizeLevel forAxis:UILayoutConstraintAxisHorizontal];
}

-(void)drawRect:(CGRect)rect{
    [super drawRect:rect];
    
    //设置左侧空白
    CGRect textRect=_searchTextField.bounds;
    CGFloat radius=textRect.size.height/2.0;
    _searchTextField.layer.cornerRadius=radius;
    
    UIView *leftView=[[UIView alloc]initWithFrame:(CGRect){0,0,radius,0}];
    _searchTextField.leftView=leftView;
}
@end
