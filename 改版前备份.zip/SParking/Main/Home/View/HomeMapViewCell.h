//
//  HomeMapViewCell.h
//  SParking
//
//  Created by Yazhao on 2018/1/9.
//  Copyright © 2018年 Yazhao. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SMapView;
@interface HomeMapViewCell : UICollectionViewCell
@property(nonatomic,strong)SMapView *mapView;
@end
