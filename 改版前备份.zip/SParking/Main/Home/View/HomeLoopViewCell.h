//
//  HomeLoopViewCell.h
//  SParking
//
//  Created by Yazhao on 2018/1/9.
//  Copyright © 2018年 Yazhao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeLoopViewCell : UICollectionViewCell
@property(nonatomic,strong)SDCycleScrollView *cycleScrollView;
@end
