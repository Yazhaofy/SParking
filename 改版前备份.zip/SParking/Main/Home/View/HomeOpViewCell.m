//
//  HomeOpViewCell.m
//  SParking
//
//  Created by Yazhao on 2018/1/10.
//  Copyright © 2018年 Yazhao. All rights reserved.
//

#import "HomeOpViewCell.h"

@implementation HomeOpViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    self.layer.cornerRadius=3;
}

@end
