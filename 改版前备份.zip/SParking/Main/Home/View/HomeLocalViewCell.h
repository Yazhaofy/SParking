//
//  HomeLocalViewCell.h
//  SParking
//
//  Created by Yazhao on 2018/1/9.
//  Copyright © 2018年 Yazhao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeLocalViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIButton *cityOptionButton;
@property (weak, nonatomic) IBOutlet UITextField *searchTextField;
@property (weak, nonatomic) IBOutlet UIImageView *searchImageView;
@property (weak, nonatomic) IBOutlet UIView *rightBlankView;

@end
