//
//  HomeMapViewCell.m
//  SParking
//
//  Created by Yazhao on 2018/1/9.
//  Copyright © 2018年 Yazhao. All rights reserved.
//

#import "HomeMapViewCell.h"
#import "SMapView.h"

@implementation HomeMapViewCell
-(instancetype)initWithFrame:(CGRect)frame{
    self=[super initWithFrame:frame];
    if(self){
        self.contentView.backgroundColor=[UIColor whiteColor];
        
        [self.contentView addSubview:self.mapView];
        [self layoutMapView];
    }
    return self;
}

-(SMapView*)mapView{
    if(!_mapView){
        _mapView=[[SMapView alloc]init];
        _mapView.userInteractionEnabled=NO;
    }
    return _mapView;
}

-(void)layoutMapView{
    [_mapView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.contentView.safeAreaInsets);
    }];
}
@end
