//
//  HomeLoopViewCell.m
//  SParking
//
//  Created by Yazhao on 2018/1/9.
//  Copyright © 2018年 Yazhao. All rights reserved.
//

#import "HomeLoopViewCell.h"

@implementation HomeLoopViewCell

-(instancetype)initWithFrame:(CGRect)frame{
    self=[super initWithFrame:frame];
    if(self){
        NSArray *imgArr=@[@"home_loop0",@"home_loop1",@"home_loop2"];
        
        _cycleScrollView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectZero shouldInfiniteLoop:YES imageNamesGroup:imgArr];
        _cycleScrollView.pageControlStyle = SDCycleScrollViewPageContolStyleAnimated;
        _cycleScrollView.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        _cycleScrollView.autoScrollTimeInterval = 4.0;
        [self.contentView addSubview:_cycleScrollView];
    }
    return self;
}

-(void)layoutSubviews{
    _cycleScrollView.frame=self.contentView.bounds;
}
@end
