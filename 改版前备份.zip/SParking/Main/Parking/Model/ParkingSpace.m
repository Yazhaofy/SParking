//
//  ParkingSpace.m
//  SParking
//
//  Created by Yazhao on 2018/1/17.
//  Copyright © 2018年 Yazhao. All rights reserved.
//

#import "ParkingSpace.h"

@implementation ParkingSpace

@end
