//
//  LoginAccountCell.h
//  SParking
//
//  Created by Yazhao on 2018/1/11.
//  Copyright © 2018年 Yazhao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginAccountCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UITextField *accountTextField;
@end
