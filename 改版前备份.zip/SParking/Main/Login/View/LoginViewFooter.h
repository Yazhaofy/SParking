//
//  LoginViewFooter.h
//  SParking
//
//  Created by Yazhao on 2018/1/11.
//  Copyright © 2018年 Yazhao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewFooter : UITableViewHeaderFooterView
@property(nonatomic,weak)IBOutlet UIButton *forgetPasswdButton;
@property(nonatomic,weak)IBOutlet UIButton *loginButton;
@property(nonatomic,weak)IBOutlet UIButton *registerButton;
@end
