//
//  MapViewController.h
//  SParking
//
//  Created by Yazhao on 2018/1/10.
//  Copyright © 2018年 Yazhao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MapViewController : UIViewController
@property(nonatomic,assign)BOOL isSearch;
@end
