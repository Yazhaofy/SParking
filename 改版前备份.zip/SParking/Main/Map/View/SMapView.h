//
//  SMapVIew.h
//  SParking
//
//  Created by Yazhao on 2018/1/12.
//  Copyright © 2018年 Yazhao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SMapView : BMKMapView
@end
